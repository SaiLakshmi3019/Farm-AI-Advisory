import { useState } from "react";

function CropDetection({ farmer }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const farmerId =
    farmer?.id ||
    farmer?.farmer_id ||
    farmer?.user_id ||
    1;

  const handleFileChange = (event) => {
    const selectedFile = event.target.files?.[0];

    if (!selectedFile) return;

    setFile(selectedFile);
    setResult(null);
    setError("");

    const imageUrl = URL.createObjectURL(selectedFile);
    setPreview(imageUrl);
  };

  const handleAnalyze = async () => {
    if (!file) {
      setError("Please select a crop leaf image first.");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const formData = new FormData();

      formData.append("farmer_id", String(farmerId));
      formData.append("file", file);

      const response = await fetch(
        "http://127.0.0.1:8000/detection/analyze",
        {
          method: "POST",
          body: formData,
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data?.detail || "Unable to analyze the image."
        );
      }

      if (!data.success) {
        throw new Error("AI analysis was not successful.");
      }

      setResult(data);
    } catch (err) {
      console.error("Crop detection error:", err);

      setError(
        err.message ||
          "Unable to connect to the Farm AI Advisory backend."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleChangeImage = () => {
    setFile(null);
    setPreview(null);
    setResult(null);
    setError("");
  };

  const getConfidenceClass = (level) => {
    if (level === "High") return "high";
    if (level === "Medium") return "medium";
    return "low";
  };

  return (
    <div className="crop-detection-page">

      {/* Header */}
      <div className="detection-header">
        <div className="plant-icon">🌿</div>

        <h1>AI Crop Disease Detection</h1>

        <p>
          Upload a clear crop leaf image for AI-powered analysis.
        </p>
      </div>

      {/* Upload Section */}
      {!result && (
        <div className="detection-card">

          {!preview ? (
            <label className="upload-box">
              <div className="upload-icon">📷</div>

              <h3>Upload Crop Image</h3>

              <p>
                JPG, JPEG, PNG or WEBP
              </p>

              <span className="upload-button">
                Choose Image
              </span>

              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleFileChange}
                hidden
              />
            </label>
          ) : (
            <>
              <div className="image-preview-container">
                <img
                  src={preview}
                  alt="Selected crop"
                  className="crop-preview"
                />

                <div className="file-info">
                  <div>
                    <strong>{file?.name}</strong>

                    <span>
                      {file
                        ? `${(file.size / 1024 / 1024).toFixed(2)} MB`
                        : ""}
                    </span>
                  </div>

                  <button
                    type="button"
                    className="change-image-button"
                    onClick={handleChangeImage}
                    disabled={loading}
                  >
                    Change Image
                  </button>
                </div>
              </div>

              <button
                type="button"
                className="analyze-button"
                onClick={handleAnalyze}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner"></span>
                    Analyzing Image...
                  </>
                ) : (
                  <>
                    🔍 Analyze Crop
                  </>
                )}
              </button>

              {loading && (
                <p className="loading-message">
                  AI is analyzing your leaf image. Please wait...
                </p>
              )}
            </>
          )}

          {/* Error */}
          {error && (
            <div className="error-box">
              <strong>⚠️ Analysis Error</strong>
              <p>{error}</p>

              <button
                type="button"
                onClick={() => setError("")}
              >
                Close
              </button>
            </div>
          )}
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="result-section">

          <div className="result-header">
            <div>
              <h2>🌱 AI Detection Result</h2>
              <p>
                Analysis completed successfully.
              </p>
            </div>

            <button
              type="button"
              className="new-analysis-button"
              onClick={handleChangeImage}
            >
              + New Analysis
            </button>
          </div>

          {/* Main Result Cards */}
          <div className="result-grid">

            <div className="result-card">
              <span>Crop Type</span>
              <strong>
                {result.crop_type || "Unknown"}
              </strong>
            </div>

            <div className="result-card">
              <span>Detected Condition</span>
              <strong>
                {result.disease || "Unknown"}
              </strong>
            </div>

            <div className="result-card">
              <span>Confidence</span>
              <strong>
                {result.confidence_percent ?? 0}%
              </strong>

              <small
                className={`confidence ${getConfidenceClass(
                  result.confidence_level
                )}`}
              >
                {result.confidence_level || "Low"} Confidence
              </small>
            </div>

            <div className="result-card">
              <span>Severity</span>
              <strong>
                {result.severity || "Unknown"}
              </strong>
            </div>

          </div>

          {/* Warning */}
          {result.warning && (
            <div className="warning-box">
              ⚠️ <strong>Important:</strong>{" "}
              {result.warning}
            </div>
          )}

          {/* Recommendation */}
          <div className="recommendation-card">
            <h3>🌾 Agricultural Recommendation</h3>

            <p>
              {result.recommendation ||
                "No recommendation available."}
            </p>
          </div>

          {/* Top Predictions */}
          {Array.isArray(result.top_predictions) &&
            result.top_predictions.length > 0 && (
              <div className="predictions-card">
                <h3>AI Prediction Details</h3>

                {result.top_predictions.map(
                  (prediction, index) => (
                    <div
                      className="prediction-row"
                      key={index}
                    >
                      <div className="prediction-name">
                        <span>
                          #{index + 1}
                        </span>

                        <strong>
                          {prediction.label}
                        </strong>
                      </div>

                      <div className="prediction-score">
                        <div className="progress-bar">
                          <div
                            className="progress-fill"
                            style={{
                              width: `${Math.min(
                                prediction.confidence_percent ||
                                  0,
                                100
                              )}%`,
                            }}
                          ></div>
                        </div>

                        <span>
                          {prediction.confidence_percent ??
                            0}
                          %
                        </span>
                      </div>
                    </div>
                  )
                )}
              </div>
            )}

          {/* Verification */}
          <div className="verification-box">
            <h3>🔎 AI Verification Note</h3>

            <p>
              This result is generated by an AI image
              classification model. For important crop
              treatment decisions, verify the diagnosis with
              a qualified agricultural expert, especially when
              confidence is low or medium.
            </p>
          </div>

        </div>
      )}

      <style>{`
        .crop-detection-page {
          max-width: 1000px;
          margin: 0 auto;
          padding: 30px 20px 60px;
          font-family: Arial, sans-serif;
        }

        .detection-header {
          text-align: center;
          margin-bottom: 30px;
        }

        .plant-icon {
          font-size: 42px;
          margin-bottom: 8px;
        }

        .detection-header h1 {
          margin: 0;
          font-size: 32px;
          color: #164e3d;
        }

        .detection-header p {
          color: #718096;
          font-size: 16px;
          margin-top: 10px;
        }

        .detection-card {
          background: white;
          border-radius: 20px;
          padding: 25px;
          box-shadow: 0 8px 30px rgba(0,0,0,0.08);
        }

        .upload-box {
          min-height: 280px;
          border: 2px dashed #9cc7b6;
          border-radius: 18px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          cursor: pointer;
          background: #f7fbf9;
        }

        .upload-icon {
          font-size: 50px;
        }

        .upload-box h3 {
          color: #164e3d;
          margin: 12px 0 5px;
        }

        .upload-box p {
          color: #718096;
        }

        .upload-button {
          background: #16734f;
          color: white;
          padding: 12px 25px;
          border-radius: 10px;
          margin-top: 10px;
          font-weight: bold;
        }

        .image-preview-container {
          border: 1px solid #d8e5df;
          border-radius: 18px;
          overflow: hidden;
        }

        .crop-preview {
          width: 100%;
          max-height: 500px;
          object-fit: contain;
          display: block;
          background: #f5f7f6;
        }

        .file-info {
          padding: 15px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 15px;
          background: #f8fbf9;
        }

        .file-info div {
          display: flex;
          flex-direction: column;
          gap: 5px;
        }

        .file-info span {
          color: #718096;
          font-size: 13px;
        }

        .change-image-button {
          padding: 10px 18px;
          border: 1px solid #16734f;
          border-radius: 10px;
          background: white;
          color: #16734f;
          cursor: pointer;
          font-weight: bold;
        }

        .analyze-button {
          width: 100%;
          margin-top: 20px;
          padding: 16px;
          border: none;
          border-radius: 12px;
          background: #16734f;
          color: white;
          font-size: 17px;
          font-weight: bold;
          cursor: pointer;
        }

        .analyze-button:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .spinner {
          display: inline-block;
          width: 16px;
          height: 16px;
          border: 3px solid rgba(255,255,255,0.4);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
          margin-right: 8px;
          vertical-align: middle;
        }

        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }

        .loading-message {
          text-align: center;
          color: #718096;
          margin-top: 12px;
        }

        .error-box {
          margin-top: 20px;
          padding: 16px;
          border-radius: 12px;
          background: #fff1f1;
          border: 1px solid #f1b5b5;
          color: #8a2525;
        }

        .error-box p {
          margin: 8px 0;
        }

        .error-box button {
          border: none;
          background: #8a2525;
          color: white;
          padding: 7px 15px;
          border-radius: 7px;
          cursor: pointer;
        }

        .result-section {
          margin-top: 25px;
        }

        .result-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 15px;
          margin-bottom: 20px;
        }

        .result-header h2 {
          color: #164e3d;
          margin: 0;
        }

        .result-header p {
          color: #718096;
        }

        .new-analysis-button {
          border: none;
          background: #16734f;
          color: white;
          padding: 11px 18px;
          border-radius: 10px;
          cursor: pointer;
          font-weight: bold;
        }

        .result-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 15px;
        }

        .result-card {
          background: white;
          padding: 20px;
          border-radius: 15px;
          box-shadow: 0 5px 20px rgba(0,0,0,0.07);
        }

        .result-card span {
          display: block;
          color: #718096;
          font-size: 14px;
          margin-bottom: 8px;
        }

        .result-card strong {
          display: block;
          color: #164e3d;
          font-size: 20px;
        }

        .confidence {
          margin-top: 8px;
          font-size: 13px;
          font-weight: bold;
        }

        .confidence.high {
          color: #178044;
        }

        .confidence.medium {
          color: #a06a00;
        }

        .confidence.low {
          color: #a52c2c;
        }

        .warning-box {
          margin-top: 20px;
          padding: 15px;
          border-radius: 12px;
          background: #fff8e5;
          border: 1px solid #ead38b;
          color: #745700;
        }

        .recommendation-card,
        .predictions-card,
        .verification-box {
          margin-top: 20px;
          background: white;
          padding: 22px;
          border-radius: 15px;
          box-shadow: 0 5px 20px rgba(0,0,0,0.07);
        }

        .recommendation-card h3,
        .predictions-card h3,
        .verification-box h3 {
          margin-top: 0;
          color: #164e3d;
        }

        .recommendation-card p,
        .verification-box p {
          line-height: 1.7;
          color: #4a5568;
        }

        .prediction-row {
          padding: 13px 0;
          border-bottom: 1px solid #edf2ef;
        }

        .prediction-row:last-child {
          border-bottom: none;
        }

        .prediction-name {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 8px;
        }

        .prediction-name span {
          background: #e7f3ed;
          color: #16734f;
          padding: 4px 8px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: bold;
        }

        .prediction-name strong {
          color: #2d3748;
        }

        .prediction-score {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .progress-bar {
          flex: 1;
          height: 8px;
          background: #e7ece9;
          border-radius: 10px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: #16734f;
          border-radius: 10px;
        }

        .prediction-score > span {
          width: 55px;
          text-align: right;
          color: #4a5568;
          font-weight: bold;
          font-size: 13px;
        }

        .verification-box {
          background: #f5faf7;
          border: 1px solid #d8e8df;
        }

        @media (max-width: 750px) {
          .result-grid {
            grid-template-columns: repeat(2, 1fr);
          }

          .result-header {
            flex-direction: column;
            align-items: flex-start;
          }
        }

        @media (max-width: 500px) {
          .result-grid {
            grid-template-columns: 1fr;
          }

          .file-info {
            flex-direction: column;
            align-items: flex-start;
          }

          .change-image-button {
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
}

export default CropDetection;